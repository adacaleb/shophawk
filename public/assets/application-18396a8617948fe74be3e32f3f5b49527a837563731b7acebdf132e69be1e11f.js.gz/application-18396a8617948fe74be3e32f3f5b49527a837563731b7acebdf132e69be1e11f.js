// Configure your import map in config/importmap.rb. Read more: https://github.com/rails/importmap-rails
import "controllers"
import "@hotwired/turbo-rails"
import "@rails/request.js"

//= require Chart.bundle
//= require chartkick;
